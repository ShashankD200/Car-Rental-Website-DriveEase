<script>
    const a = "abb";
const b = "baa";
var i =0;
var j =0;
if( a != b ){

    var split_a = a.split("");
    var split_b = b.split("");

 for(i=0;i<split_a.length;i++){
  
var d = split_a[i];
   
for(j=0;j<split_b.length;j++){
    
var e = split_b[i];
   
 }

if(d=e){
   
}else{
    console.log("The two Strings are not  equal");
}


 }
 console.log("The two Strings are  equal");
 


    
    
}else{
    console.log("The two string are equal.")
}
    
    </script>