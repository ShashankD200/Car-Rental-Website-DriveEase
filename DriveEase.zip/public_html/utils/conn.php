<?php

$servername = "localhost";
$username = "id21338512_root";
$password = "aS?\&65mi@_?pU~^";
$database = "id21338512_car_rental";


$conn = new mysqli($servername, $username, $password, $database);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8");

?>
