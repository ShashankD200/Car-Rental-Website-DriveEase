
<footer class="bg-white py-4 mt-auto" style="position:fixed;bottom:0;width:100%;">
        <div class="container px-5">
            <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                <div class="col-auto"><div class="small m-0">Copyright &copy; DriveEase 2023</div></div>
                <div class="col-auto"><div class="small m-0">Designer / Shashank Dewangan</div></div>
                
            </div>
        </div>
    </footer>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
      integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script>
  var user_id = <?php echo json_encode($user_id); ?>;
  var user_type = <?php echo json_encode($user_type); ?>;

    </script>

 